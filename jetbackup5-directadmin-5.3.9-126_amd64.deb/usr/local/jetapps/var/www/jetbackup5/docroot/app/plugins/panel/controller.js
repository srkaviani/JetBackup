'use strict';

define(['app'], function(app) {
	app.controller("panelSettings",
		["$rootScope", "$scope", "$routeParams", "$uibModal", "$location", "$timeout", "api", "util", "consts", "lang",
			function ($rootScope, $scope, $routeParams, $uibModal, $location, $timeout, api, util, consts, lang) {

				if($scope.saveData.options && !$scope.saveData.options.api_timeout) $scope.saveData.options.api_timeout = 30;
			}
		]
	);
});