#!/bin/sh

echo "This plugin was installed via yum"
exit 0;