#!/bin/bash

syncAccounts() {
  sleep 5
  USERNAME=$( printenv user )
  /usr/local/jetapps/usr/bin/jetbackup5/sync_accounts $USERNAME
}

#closing all FDs
for fd in $(ls /proc/$$/fd); do
  eval "exec $fd>&-"
done

syncAccounts &
exit 0
