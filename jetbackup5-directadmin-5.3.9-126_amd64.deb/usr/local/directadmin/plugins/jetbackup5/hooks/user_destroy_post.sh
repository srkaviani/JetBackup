#!/bin/bash

syncAccounts() {

  ACCOUNT=$( printenv username )
  [[ -z "$ACCOUNT" ]] && exit 1
  TIMEOUT=120
  TIMEPASSED=0
  CACHE_FILE="/usr/local/directadmin/data/admin/show_all_users.cache"
  WATCH_FILE="/usr/local/jetapps/var/run/jetbackup5/sync_accounts.watch"

  while true; do
    cat $CACHE_FILE | grep -E "^$ACCOUNT=" >/dev/null
    if [[ $? -ne 0 ]]; then
      /usr/local/jetapps/usr/bin/jetbackup5/sync_accounts $ACCOUNT
      exit 0
    fi
    TIMEPASSED=$((TIMEPASSED+1))
    [[ $TIMEPASSED -ge $TIMEOUT ]] && exit 1
    sleep 1
  done
}

#closing all FDs
for fd in $(ls /proc/$$/fd); do
  eval "exec $fd>&-"
done

syncAccounts &
exit 0
