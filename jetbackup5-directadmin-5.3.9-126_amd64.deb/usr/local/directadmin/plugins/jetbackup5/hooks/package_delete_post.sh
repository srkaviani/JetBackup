#!/bin/bash

syncAccounts() {
  sleep 5
  PKG_FILE=$( printenv package_filename )
  if [[ $PKG_FILE =~ data/users ]]; then
    USERNAME=$( echo $PKG_FILE | sed 's/^.*\/data\/users\/\([^\/]\+\).*$/\1/g' )
  else
    USERNAME="admin"
  fi
  /usr/local/jetapps/usr/bin/jetbackup5/sync_accounts $USERNAME
}

#closing all FDs
for fd in $(ls /proc/$$/fd); do
  eval "exec $fd>&-"
done

syncAccounts &
exit 0
