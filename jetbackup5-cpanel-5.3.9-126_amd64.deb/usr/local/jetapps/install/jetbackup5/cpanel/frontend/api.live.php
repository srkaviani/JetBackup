<?php

require_once("/usr/local/cpanel/php/cpanel.php");
$cpanel = new CPANEL();

$params = $_REQUEST;
$input = file_get_contents('php://input');
if($input) {
	$input = json_decode($input,true);
	if($input !== false) $params = array_merge($params, $input);
}


if(!$params['function']) {

	die(json_encode([
		'success'   => false,
		'message'   => "No function was provided",
		'system'    => [],
		'data'      => []
	]));
}

$data = $cpanel->uapi('JetBackup5', "wrapper", [ 'params' => base64_encode(serialize($params)) ]);
$result = $data['cpanelresult']['result'];

if(!$result['status']) {
	die(json_encode(array_merge([
		'success'   => false,
		'message'   => isset($result['errors'][0]) ? $result['errors'][0] : "Unknown Error",
	], $result['data'] ? $result['data'] : [])));
}

die(json_encode(array_merge([
	'success'   => true,
	'message'   => isset($result['messages'][0]) ? $result['messages'][0] : "",
], $result['data'] ? $result['data'] : [])));

?>