<?php

require_once("/usr/local/cpanel/php/cpanel.php");
$cpanel = new CPANEL();

$data = $cpanel->uapi('JetBackup5', 'wrapper', [ 'function' => 'panelPreload' ]);
$result = $data['cpanelresult']['result'];
$version = $result['status'] ? $result['data']['system']['version'] : '';

$data = $cpanel->uapi('Locale', 'get_attributes');
$result = $data['cpanelresult']['result'];
$language = $result['status'] ? $result['data'] : ['locale' => 'en', 'direction' => 'ltr' ];

?>
<!doctype html>
<html lang="<?php echo $language['locale']; ?>" dir="<?php echo $language['direction']; ?>">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="" />
	<title>JetBackup 5</title>

	<script src="libraries/main.js?v=<?php echo $version; ?>" type="text/javascript"></script>
	<link rel="stylesheet" href="libraries/main.css?v=<?php echo $version; ?>" />
</head>
<body>

<div ng-include="'app/views/main.htm?v=<?php echo $version; ?>'" ng-controller="JetBackup" id="JetBackup" class="<?php echo $language['direction']; ?>"></div>
<script type="text/javascript">
	new JetBackup({
        template: 'enduser',
		language: '<?php echo $language['locale']; ?>',
		entrypoints: {
			api: './api.live.php?v=<?php echo $version; ?>',
			download: './download.html?v=<?php echo $version; ?>',
		},
		path: {
			media: '.'
		}
	});
</script>

</body>
</html>
