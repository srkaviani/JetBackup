package Cpanel::Template::Plugin::JetBackup5;


use strict;

use base 'Template::Plugin';

sub new {
	my ($class) = @_;
	my $plugin = { 'run' => \&_run };
	return bless $plugin, $class;
}

sub _run {
	system("/usr/local/jetapps/usr/bin/jetbackup5/jetbackup_admin");
	exit;
}

1;