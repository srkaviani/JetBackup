package Cpanel::API::JetBackup5;

use strict;
use CGI;

our $VERSION = '1.0';
 
use Cpanel                   ();
use Cpanel::API              ();
use Cpanel::Locale           ();
use Cpanel::Logger           ();
use Cpanel::LiveAPI          ();
use Data::Dumper             ();
use Cpanel::Wrap             ();
use CGI;
use URI::Escape;
use PHP::Serialization qw( unserialize );
use MIME::Base64;

# Globals
my $logger;
my $locale;

sub wrapper {
	my($args, $result) = @_;

	$logger ||= Cpanel::Logger->new();
	$locale ||= Cpanel::Locale->get_handle();

	#$args->add('language', $locale->get_language_tag());

	my $feature = 'jetbackup5';

	if(!main::hasfeature($feature))
	{
		$result->error('_ERROR_FEATURE', $feature);
		return;
	}

	if($Cpanel::CPDATA{'DEMO'})
	{
		$result->error('_ERROR_DEMO_MODE', $feature);
		return;
	}

	my $request_args = unserialize(decode_base64($args->get('params')));

	my $wrap_result = Cpanel::Wrap::send_cpwrapd_request(
		'namespace' => "JetApps",
		'module'    => "JetBackup5",
		'function'  => $request_args->{'function'},
		'data'      => $request_args,
		#'action' 	=> 'fetch',
		'env'    	=> Cpanel::Wrap::Config::safe_hashref_of_allowed_env(),
	);

    my $error = $wrap_result->{'error'};
	my $data = $wrap_result->{'data'};

    if($error) {
		if($wrap_result->{'statusmsg'}) { $result->error($wrap_result->{'statusmsg'}) }
		else { $result->error('Error code ' . $wrap_result->{'exit_code'} . ' returned: ' . $wrap_result->{'data'}) }
		return 0;
	}
	elsif(ref($data) || defined($data)) {
		if(ref($data)) { my $data = Data::Dumper::Dumper($data); }

		my $response = unserialize(decode_base64($data));

		my $response_data = {};
		$response_data->{'data'} = $response->{'data'};
		$response_data->{'system'} = $response->{'system'};

		$result->data($response_data);

		if($response->{'success'}) {
			$result->message($response->{'message'});
			return 1;
		} else {
			$result->error($response->{'message'});
			return 0;
		}
	}
	else {
		$result->error('Request Failed: ' . $wrap_result->{'statusmsg'});
		return 0;
	}
}

1;
