package Cpanel::Config::ConfigObj::Driver::JetBackup5::META;

use strict;

use parent qw(Cpanel::Config::ConfigObj::Interface::Config::Version::v1);

our $VERSION = 1.1;

use Cpanel::Config::ConfigObj::Driver::JetBackup5 ();

sub meta_version {
    return 1;
}

sub get_driver_name {
    return 'JetBackup5_driver';
}

sub content {
    my ($locale_handle) = @_;

    my $content = {
        'vendor' => 'JetApps',
        'url'    => 'www.jetapps.com',
        'name'   => {
            'short'  => 'JetBackup 5 Driver',
            'long'   => 'JetBackup 5 Driver',
            'driver' => get_driver_name(),
        },
        'since'    => 'cPanel 11.38.1',
        'abstract' => "A JetBackup 5 driver",
        'version'  => $Cpanel::Config::ConfigObj::Driver::JetBackup5::VERSION,
    };

    if ($locale_handle) {
        $content->{'abstract'} = $locale_handle->maketext("JetBackup 5 driver");
    }

    return $content;
}

sub showcase {
    return;
}

sub spec_version {
    return 1;
}
1;
